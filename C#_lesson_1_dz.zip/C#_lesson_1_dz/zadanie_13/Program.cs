﻿// Напишите программу, которая выводит третью цифру заданного числа или сообщает, что третьей цифры нет.
// 645 -> 5
// 78 -> третьей цифры нет
// 32679 -> 6

Console.WriteLine("Введите число: ");
int number = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Введите номер цифры, которую хотите получить,нумерация начинается с 1");
int digitUser = Convert.ToInt32(Console.ReadLine());
string thirdDigit = GetThirdDigit(number,digitUser);
Console.WriteLine($"{number} -> {thirdDigit}");
// функция выводит любую цифру заданного числа
string GetThirdDigit(int num,int digUser)//решил так реализовать функцию,потому что в прошлом дз из-за массива было замечание
{
    int forSaveNum = num;
    int pow;
    int countDigit = 1;//так число итераций будет на 1 меньше чем цифр в числе поэтому начинаем с 1
    while (num > 9 || num < -9)//цикл для того чтобы найти количество цифр числа
    {
        num = num / 10;
        countDigit++;
    }
    pow = Convert.ToInt32(Math.Pow(10,countDigit-digUser));
    return (countDigit == 2) ? "Третьей цифры нет" : $"{Convert.ToString(forSaveNum / pow % 10)}";
}

