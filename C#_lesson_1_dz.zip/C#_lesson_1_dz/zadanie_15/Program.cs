﻿// Напишите программу, которая принимает на вход цифру, обозначающую день недели, и проверяет, является ли этот день выходным.
// 6 -> да
// 7 -> да
// 1 -> нет

Console.WriteLine("Номер дня недели 1-7");
int dayOfWeek = Convert.ToInt32(Console.ReadLine());
bool today = DayOfWeek(dayOfWeek);
Console.WriteLine($"{dayOfWeek} -> {today}");

bool DayOfWeek(int dayWeek) {
    return (dayWeek == 6 || dayWeek == 7) ? true : false;
}
